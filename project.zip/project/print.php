<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
   unset($user_id);
   session_destroy();
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-x1-12">
                <h1 class="text-center">Customer Details</h1>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>name</th>
                            <th>email</th>
                            <th>password</th>
                            <th>image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql = "SELECT * FROM user_form";
                        $result = mysqli_query($conn, $sql);

                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            
                        ?>
                        <tr>
                           
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['password'] ?></td>
                             <td><?php echo $row['image'] ?></td>
                        </tr>
                        <?php
                        
                        }
                        ?>
                    </tbody>
                </table>
                <div class="text-center">
                        <!-- <button onclcik="window.print()" ">Print</button> -->
                     <button >   <a onclick="window.print()">Print page</a> </button>
                </div>
            </div>
</div>
    </div>
</body>
</html>

